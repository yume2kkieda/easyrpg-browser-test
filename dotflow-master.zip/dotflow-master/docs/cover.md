![logo](_media/icon.png)

# Dotflow

> 一个神奇的前端工作平台

* 基于electron，本地安装运行，可视化界面操作便捷
* 预置多种脚手架，切图、开发效率提升200%
* 支持git线上脚手架，本地脚手架导入

[GitHub](https://github.com/hyruleteam/dotflow)
[快速开始](#是什么)