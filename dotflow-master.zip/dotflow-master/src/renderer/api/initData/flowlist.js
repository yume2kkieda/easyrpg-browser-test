const data = [{
  _id:'1',
  avatar: 'H',
  name: 'hllui-pc',
  description: '这是切图必备生成器',
  type: 'git',
  isDefault: 1,
  tempURL:'git@github.com:hyruleteam/dotflow_gulp_pc.git',
},{
  _id:'2',
  avatar: 'H',
  name: 'hllui-mobile',
  description: '这是切图必备生成器',
  type: 'git',
  isDefault: 1,
  tempURL:'git@github.com:hyruleteam/dotflow_gulp_mobile.git',
}, {
  _id:'3',
  avatar: 'V',
  name: 'hyrule-laravel-vue',
  description: '最顺手的vue-admin脚手架',
  type: 'git',
  isDefault: 1,
  tempURL:'git@github.com:wenyuking/hyrule-laravel-vue.git',
}];

export default data;
