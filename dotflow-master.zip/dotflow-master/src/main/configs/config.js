import Config from 'electron-config';

export default new Config({ name: 'config' });
